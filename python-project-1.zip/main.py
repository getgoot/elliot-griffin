'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

number = list(range(1500,2700)) 

for i in number:
    print(number[5:1500:7])
    break
    


    
    
    
    
        
