'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

''' 
def fizz_buzz(numlist):
    if num%3==0 and num%5==0:
        return 'fizzbuzz' 
        
    elif num % 3 == 0:
        return 'fizz' 
        
    elif num % 5 == 0:
        return 'buzz'
    else:
        return numlist
        
for n in range(1,51):
    print(fizz_buzz(n))
