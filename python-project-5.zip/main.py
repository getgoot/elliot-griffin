'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import sys
import os

player1 = input("Rock Paper or scissors: ")
player2 = input("Rock Paper or scissors: ") 

Paper = 'P'
Scissors = 'S' 
Rock = 'R' 

if player1 == 'P' and player2 == 'R':
    print('player1 wins')

if player1 == 'R' and player2 == 'P':
    print('player2 wins') 
    
if player1 == 'S' and player2 == 'P':
    print('player1 wins') 
    
if player1 == 'P' and player2 == 'S':
    print('player2 wins') 
    
if player1 == 'R' and player2 == 'S':
    print('player1 wins') 

if player1 == 'S' and player2 == 'R':
    print('player2 wins') 

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

if __name__== "__main__":
    answer = input("do you want to restart this program ? ")
    if answer.lower().strip() in "y yes".split():
        restart_program()
    