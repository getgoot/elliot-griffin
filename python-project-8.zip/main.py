'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
farenheit = int(input('type in farenheit to be converted to celcius: '))
celcius = int(input('type in celcius to be converted to farenheit: '))

C_result = 5/9 * (farenheit - 32)
F_result = (celcius * 1.8) + 32

print(farenheit,'°F is',C_result,'in celcius') 

print(celcius, '°C is',F_result,'in farenheit')

